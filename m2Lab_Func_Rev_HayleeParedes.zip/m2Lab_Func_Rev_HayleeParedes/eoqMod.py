# Define EOQ, calculate EOQ, and return either EOQ or miniOrder based on which is higher. 
# Feb. 10, 2025
# CSC-121 m2Lab-Function Review
# Haylee Paredes

'''
Step 1: define eoq with the parameters; demand, reoderCost, holdingCost, and minOrder.
Step 2: Use the EOQ formula to calculate the EOQ.  
Step 3: return the EOQ or the miniOrder depending on which is higher. Use "max" to achieve this. It compares the two to find out which is higher. 
'''

# Define eoq. Demand, reorderCost, holdingCost, and miniOrder.
def eoq(demand, reorderCost, holdingCost, minOrder):
    # Calculate eoq with ((2 * demand * reorderCost) / holdingCost) ** 0.5
    eoqNum = ((2 * demand * reorderCost) / holdingCost) ** 0.5
    # Return which ever value is the highest to eoq_m2Lab. 
    return max(eoqNum, minOrder)