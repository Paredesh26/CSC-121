# Getting demand, reorderCOst, holdingCost, and miniOrder from user and 
# Feb. 10, 2025
# CSC-121 m2Lab-Function Review
# Haylee Paredes

'''
Step 1: import EOQ_m2Lab.
Step 2: get demand value from user.
Step 3: get reorder cost from user.
Step 4: get holding cost from user.
Step 5: get minimum order from user.
Step 6: calculate the EOQ or minimum order size if the order size is higher than the EOQ.
Step 7: Display the EOQ or the minimumorder size.
Step 8: Create options for user to choose from and make it loop until user decides to quit the program.
'''
# import the EOQ_m2Lab file to eoq_m2Lab
import eoqMod

# Define main
def calEOQ():

    print('_'* 50)
    
    # Get demand from user
    demand = float(input("\nEnter annual projetced demand (units/year): "))

    # Get reorder cost from user
    reorderCost = float(input("\nEnter the reorder cost ($/order): "))

    # Get holding cost from user
    holdingCost = float(input("\nEnter the holding cost ($/year/unit): "))

    # Get minimum order from user
    minOrder = float(input("\nEnter the minimun order size (units/order): "))

    # Call EOQ_m2Lab and refer to eoq(), then pass demand, reorderCost, holdingCost, and minOrder into eoq.
    eoqFinal = eoqMod.eoq(demand, reorderCost, holdingCost, minOrder)

    # Display eoq or minimum order size depending on which is the highest.
    if minOrder < eoqFinal:
        # Print eoq is minOrder is the lowest.
        print(f"\nEconomic Order Quantity: {round(eoqFinal)}")
    else:
        # Print minOrder is eoq is the lowest.
        print(f"\nMinimum Order Size: {minOrder}")

    print('_'*50)

def main():

    exit_Prog = 'yes'

    while exit_Prog.lower() == 'yes':
        user_option = input("\nCalculate Economic Order Quantity? (yes/no): ")

        # If user enters 'yes' then calculate EOQ.
        if user_option == "yes":
            # Calculate EOQ.
            calEOQ()

        # If user enters 'no' loop ends and program ends. 
        elif user_option == "no":
            # Stop loop.
            exit_Prog = 'no'
            # Display to user that the program is ending.
            print("\nExiting Program...")
        else:
            # Display if user doesn't enter a vaild option. 
            print("\nPlease enter a vaild option!")

# Run main
if __name__ == "__main__":
    main()

