# Allows the user to calculate tuition cost for students depending on the courses they are taking.
# Feb. 27, 2025
# CSC-121 m3Pro - Purchases
# Haylee Paredes

# main_program.py

# Importing functions from tuition_calculator.py
from tuition_calculator import display_courses, register_students, view_student_tuition

def main():
    """Main function to control the flow of the program."""
    while True:
        display_courses()  # Show the list of courses and their tuition
        
        # Menu options
        print("\nOptions:")
        print("1. Register students and calculate tuition.")
        print("2. Check a student's tuition.")
        print("3. Exit.")
        
        choice = input("Please choose an option (1, 2, or 3): ")
        
        if choice == '1':
            register_students()  # Option 1: Register students and calculate their tuition
        elif choice == '2':
            view_student_tuition()  # Option 2: Check a specific student's tuition
        elif choice == '3':
            print("Goodbye!")
            break  # Exit the program
        else:
            print("Invalid choice. Please try again.")

# Call main function to start the program
if __name__ == "__main__":
    main()


# 