# tuition_calculator.py

# Global Lists (Defined here so they can be accessed by the functions)
courses = ["MAT 035 (Concepts of Algebra)", "BAS 120 (Intro to Analytics)", "ENG 101 (English Composition)", "SCI 205 (General Biology)"]
tuition = [460, 500, 300, 350]
stu_names = ["John Doe", "Jane Smith", "Bob Brown", "Alice White"]

def display_courses():
    """This function prints out the courses and their tuition."""
    print("\nCourse List:")
    print(f"{'Course Name':<40} {'Tuition ($)'}")
    print("-" * 50)
    for i in range(len(courses)):
        print(f"{courses[i]:<40} {tuition[i]:<15}")

def register_students():
    """This function registers students for courses and calculates total tuition."""
    student_tuition = {}  # Create a dictionary to store each student's tuition
    for student in stu_names:
        total_tuition = 0
        print(f"\nRegistering courses for {student}:")
        for i in range(len(courses)):
            # Ask if the student is registered for each course
            register = input(f"Is {student} registered for {courses[i]}? (y/n): ").lower()
            if register == 'y':  # If 'y', add the course's tuition to the total
                total_tuition += tuition[i]
        # Store the total tuition for each student
        student_tuition[student] = total_tuition
    
    # Display the total tuition for each student
    print("\nTotal Tuition for each student:")
    print(f"{'Student Name':<20} {'Tuition ($)'}")
    print("-" * 30)
    for student, tuition_fee in student_tuition.items():
        print(f"{student:<20} {tuition_fee:<15}")

def view_student_tuition():
    """This function allows the user to check the tuition for a specific student."""
    student_number = int(input("\nEnter the student number (1 to 4): ")) - 1
    if 0 <= student_number < len(stu_names):
        total_tuition = 0
        print(f"\nChecking courses for {stu_names[student_number]}:")
        for i in range(len(courses)):
            register = input(f"Is {stu_names[student_number]} registered for {courses[i]}? (y/n): ").lower()
            if register == 'y':
                total_tuition += tuition[i]
        print(f"\nTotal Tuition for {stu_names[student_number]}: ${total_tuition}")
    else:
        print("Invalid student number.")
