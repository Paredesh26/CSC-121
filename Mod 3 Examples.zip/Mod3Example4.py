# -*- coding: utf-8 -*-
"""
Created on Mon Feb 10 14:38:14 2025

@author: paredesh3418
"""

names = ['Sammy', 'Johnson', 'Jessica', 'Sara']

# enumerate best used to find a index value of a value. 
for i, value in enumerate(names):
    print(i, value)